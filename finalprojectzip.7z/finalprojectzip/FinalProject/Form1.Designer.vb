﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDateFinder
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.nudMonthInput = New System.Windows.Forms.NumericUpDown()
        Me.nudDayInput = New System.Windows.Forms.NumericUpDown()
        Me.nudYearInput = New System.Windows.Forms.NumericUpDown()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblOutputDate = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.nudAddedDaysInput = New System.Windows.Forms.NumericUpDown()
        CType(Me.nudMonthInput, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudDayInput, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudYearInput, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudAddedDaysInput, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(52, 72)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(71, 23)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Month"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(174, 72)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(71, 23)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Day"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(302, 72)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(54, 23)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Year"
        '
        'nudMonthInput
        '
        Me.nudMonthInput.Location = New System.Drawing.Point(55, 114)
        Me.nudMonthInput.Maximum = New Decimal(New Integer() {12, 0, 0, 0})
        Me.nudMonthInput.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudMonthInput.Name = "nudMonthInput"
        Me.nudMonthInput.Size = New System.Drawing.Size(40, 20)
        Me.nudMonthInput.TabIndex = 3
        Me.nudMonthInput.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'nudDayInput
        '
        Me.nudDayInput.Location = New System.Drawing.Point(177, 114)
        Me.nudDayInput.Maximum = New Decimal(New Integer() {31, 0, 0, 0})
        Me.nudDayInput.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudDayInput.Name = "nudDayInput"
        Me.nudDayInput.Size = New System.Drawing.Size(40, 20)
        Me.nudDayInput.TabIndex = 4
        Me.nudDayInput.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'nudYearInput
        '
        Me.nudYearInput.Location = New System.Drawing.Point(294, 114)
        Me.nudYearInput.Maximum = New Decimal(New Integer() {2025, 0, 0, 0})
        Me.nudYearInput.Minimum = New Decimal(New Integer() {2000, 0, 0, 0})
        Me.nudYearInput.Name = "nudYearInput"
        Me.nudYearInput.Size = New System.Drawing.Size(62, 20)
        Me.nudYearInput.TabIndex = 5
        Me.nudYearInput.Value = New Decimal(New Integer() {2000, 0, 0, 0})
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(120, 226)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(159, 47)
        Me.btnCalculate.TabIndex = 6
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(164, 304)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(71, 23)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "New Date"
        '
        'lblOutputDate
        '
        Me.lblOutputDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblOutputDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOutputDate.Location = New System.Drawing.Point(137, 359)
        Me.lblOutputDate.Name = "lblOutputDate"
        Me.lblOutputDate.Size = New System.Drawing.Size(120, 39)
        Me.lblOutputDate.TabIndex = 8
        Me.lblOutputDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(145, 433)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(112, 37)
        Me.btnExit.TabIndex = 9
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(81, 177)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(125, 23)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Added Days (1 to 60)"
        '
        'nudAddedDaysInput
        '
        Me.nudAddedDaysInput.Location = New System.Drawing.Point(212, 175)
        Me.nudAddedDaysInput.Maximum = New Decimal(New Integer() {60, 0, 0, 0})
        Me.nudAddedDaysInput.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudAddedDaysInput.Name = "nudAddedDaysInput"
        Me.nudAddedDaysInput.Size = New System.Drawing.Size(33, 20)
        Me.nudAddedDaysInput.TabIndex = 11
        Me.nudAddedDaysInput.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'frmDateFinder
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(429, 495)
        Me.Controls.Add(Me.nudAddedDaysInput)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.lblOutputDate)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.nudYearInput)
        Me.Controls.Add(Me.nudDayInput)
        Me.Controls.Add(Me.nudMonthInput)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmDateFinder"
        Me.Text = "Date Finder - Camden"
        CType(Me.nudMonthInput, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudDayInput, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudYearInput, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudAddedDaysInput, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents nudMonthInput As NumericUpDown
    Friend WithEvents nudDayInput As NumericUpDown
    Friend WithEvents nudYearInput As NumericUpDown
    Friend WithEvents btnCalculate As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents lblOutputDate As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents nudAddedDaysInput As NumericUpDown
End Class
